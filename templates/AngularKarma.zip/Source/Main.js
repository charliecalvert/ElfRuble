 /**
 * @author Charlie Calvert
 */

 /* jshint devel: true */

angular.module('mainModule', [])
.controller('mainController', function($scope) { 'use strict';

	$scope.name = "mainController";
	
	
});



